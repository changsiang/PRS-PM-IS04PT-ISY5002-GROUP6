# fundusv3 > 2022-09-19 12:20am
https://universe.roboflow.com/object-detection/fundusv3

Provided by Roboflow
License: CC BY 4.0

